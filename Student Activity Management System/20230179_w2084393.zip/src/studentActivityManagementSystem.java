import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import java.util.jar.Attributes;

public class studentActivityManagementSystem {
    private static final int maxSize = 100;
    private static Student[] studentsArr = new Student[maxSize];
    private static int studentCount = 0;

    public static void checkAvailableSeats(){
        System.out.println("Available Seats: "+(maxSize-studentCount));
    }


    public static void registerStudent(Scanner scanner){
        String id="";
        double modMark=0;
        boolean flag=false;
        while(true){
            flag=false;
            System.out.print("Enter student id: ");
            id=scanner.next();
            if(id.length()==8){
                for(int i=0;i<studentsArr.length;i++){
                    if(studentsArr[i]!=null){
                        Student student=studentsArr[i];
                        if(student.getStuId().equals(id)){
                            System.out.println("That student is already exists.");
                            flag=true;
                            break;
                        }
                    }
                }
                if(!flag){
                    break;
                }
            }else{
                System.out.println("Enter a id with length of 8.");
            }
        }
        scanner.nextLine();
        System.out.print("Enter student name: ");
        String name=scanner.nextLine();
        String listOfNames[]=name.split(" ");
        for(int i=0;i<listOfNames.length;i++){ // Capitalize the first letter of the eaxh word in the name
            listOfNames[i]=listOfNames[i].substring(0,1).toUpperCase()+listOfNames[i].substring(1);
        }
        String first=listOfNames.length>0?listOfNames[0].trim():"";
        String second=listOfNames.length>1?listOfNames[1].trim():"";

        name=((listOfNames.length>1)?first+" ":first+"")+second;//If student entered the name of two words arranging space between them

        Module moduleArr[]=new Module[3];
        for(int i=0;i<moduleArr.length;i++){
            Module module=new Module(modMark);
            moduleArr[i]=module;
        }
        Student student=new Student(name,id,moduleArr);
        studentsArr[studentCount++]=student; //Adding the student to the array
        System.out.println("Student registered Successfully.");
    }

    public static void deleteStudent(Scanner scanner){
        int count=0;
        Student temp[]=new Student[maxSize]; //Created a temorary array to copy the new students without the deleted student
        boolean flag=false;
        if(studentsArr[0]==null){
            System.out.println("No students registered yet.");
        }
        while(true){
            System.out.print("Enter student id: ");
            String id=scanner.next();
            if(id.length()==8){
                for(int i=0;i<studentsArr.length;i++){
                    if(studentsArr[i]!=null){
                        Student student=studentsArr[i];
                        if(student.getStuId().equals(id)){
                            flag=true;
                            count=i;
                            break;
                        }
                    }
                }
                break;//Breaking the while loop after checking entered student in the array or not in the array
            }else{
                System.out.println("Enter a id with 8 characters.");
            }
        }
        for(int i=0;i<count;i++){ //Copying the elements selected id 
            temp[i]=studentsArr[i];
        }
        for(int j=count+1;j<temp.length;j++){ //Copying the elements after the equals student id in to a temporary array
            temp[j]=studentsArr[j];
        }
        studentsArr=temp; //Sharing the reference of the temporary array
        if(!flag){
            System.out.println("No such student");
            return;
        }
        System.out.println("Student deleted successfully.");
    }

    public static void storeDetailsToFile(){
        try {
            FileWriter detailsFile=new FileWriter("text.txt");
            for(int i=0;i<studentsArr.length;i++){
                if(studentsArr[i]!=null){ //checking student array i place is an empty
                    Student student=studentsArr[i];
                    Module[]modules=student.getModules();
                    detailsFile.write(student.getStuId()+","+student.getStuName()+",");// Write student name and id
                    for(int l=0;l<3;l++){
                        if(modules[l]!=null){ //Created a if statement for check student have module marks
                            detailsFile.write(modules[l].getModuleMark()+(l==2?"":","));    //Removed additional comma
                        }
                    }
                    detailsFile.write("\n");
                }
            }
            detailsFile.close();
            System.out.println("Student details successfully stored.");
        } catch (IOException e) {
            System.out.println("Text file not found.");
        }
    }
    public static void loadStudentDetailsFromFile(){
        int counter=0; //Declare and initialize for better use
        String name="";
        try {
            File file =new File("text.txt");
            Scanner reader=new Scanner(file);
            while(reader.hasNextLine()){ //Looping while text file last line
                String text=reader.nextLine(); //Reading line by line 
                String[] listOfDetails=text.split(","); //remove commas and seperate
                String id=listOfDetails[0].trim();
                name=listOfDetails[1];
                Module modules[]=new Module[3];
                for(int num=0;num<modules.length;num++){

                    double modMark=Double.parseDouble(listOfDetails[2+num].trim());//Use to convert a string in to a double
                    modules[num]=new Module(modMark);

                }
                Student student=new Student(name,id,modules); //Creating student object and entering to the array
                studentsArr[counter++]=student;
            }
            studentCount=counter;
            reader.close();
            System.out.println("Successfully lorded students to the array.");

        }catch (Exception e) {
            System.out.println("File not found");
        }
    }


    public static void findStudent(Scanner scanner){
        String id;
        int studentObj=0;
        boolean flag=false;
        if(studentsArr[0]==null){ //If studentsArr first element equals to null
            System.out.println("No students registered.");
            return;
        }
        while(true){ //while student id length equals to 8
            System.out.print("Enter your ID: ");
            id=scanner.next();
            if(id.length()==8){
                for(int i=0;i<studentsArr.length;i++){
                    if(studentsArr[i]!=null){
                        Student student=studentsArr[i];
                        if(student.getStuId().equals(id)){// if entered it equals to student id
                            flag=true;
                            studentObj=i;
                            break;
                        }
                    }
                }
                if(flag){
                    Student student=studentsArr[studentObj];
                    System.out.println("Student Name: "+student.getStuName());
                    Module modules[]=student.getModules();
                    for(int y=0;y<modules.length;y++){ //Printing 3 module marks of that student
                        System.out.println("Module "+(y+1)+" Mark: "+modules[y].getModuleMark());
                    }
                    break;
                }else{
                    System.out.println("No Such Student.");
                    return;
                }
            }else{
                System.out.println("Enter a id with 8 characters.");
            }
        }
    }

    public static void viewTheStudentWithNames(){
        //Entering all the student names in to the array
        String NamesArr[]=new String[studentCount];
        for(int i=0;i<studentsArr.length;i++){
            if(studentsArr[i]!=null){
                Student student=studentsArr[i];
                NamesArr[i]=student.getStuName();
            }
        }
        //Sorting in alphabetical order
        for(int i=0;i<NamesArr.length;i++){
            for(int y=i;y<NamesArr.length;y++){
                if(NamesArr[i].compareTo(NamesArr[y])>0){ //Compare unicode values
                    String temp=NamesArr[i];
                    NamesArr[i]=NamesArr[y];
                    NamesArr[y]=temp;

                }
            }
        }
        //Printing sorted names
        System.out.print("Student names in alphabat order: ");
        for(int i=0;i<NamesArr.length;i++){
            System.out.print(NamesArr[i]+", ");
        }
        System.out.println("\b\b "); //Remove additional comma
    }

    public static void subMenu(){
        System.out.println("Sub Menu");
        System.out.println("\t1. Add Student Marks");
        System.out.println("\t2. Summary");
        System.out.println("\t3. Report");
        System.out.println("\t4. Return to main menu");
    }

    public static void additionalOptions(Scanner scanner){
        int choice=0;
        boolean flag=false;
        while(true){
            try {
                subMenu();
                System.out.print("Enter your choice: ");
                choice=scanner.nextInt();
            } catch (Exception e) {
                System.out.print("Enter a valid integer value.");
                scanner.nextInt();// Clear the input
            }
            switch(choice){ //Checking the option using a switch
                case 1:addStudentMarks(scanner); break;
                case 2:summary(); break;
                case 3:report(); break;
                case 4:flag=true; break;
                default:System.out.println("Enter a integer in the options");
            }
            if(flag){
                System.out.println("Exiting Sub Menu...");
                break;
            }
        }
    }

    public static void addStudentMarks(Scanner scanner){
        boolean flag=false;
        if(studentsArr[0]==null){
            System.out.println("No students are added yet.");
            return;
        }
        scanner.nextLine();
        System.out.print("Enter student name: ");
        String name=scanner.nextLine();
        String namesArr[]=name.split(" ");// removes " " and sperate
        for(int i=0;i<namesArr.length;i++){
            namesArr[i]=namesArr[i].substring(0,1).toUpperCase()+namesArr[i].substring(1);//capitalize every letter in each word
        }
        String first=namesArr.length>0?namesArr[0]:"";
        String second=namesArr.length>1?namesArr[1]:"";//If student has 2 words in the name, space handling

        name=namesArr.length<2?first+"":first+" "  +(second.isEmpty()?"":second.trim());

        for(int i=0;i<studentsArr.length;i++){
            if(studentsArr[i]!=null){
                Student student=studentsArr[i];
                if(student.getStuName().equals(name)){ //Check entered name and student name is equals
                    flag=true;
                    Module moduleArr[]=student.getModules();
                    for(int s=0;s<moduleArr.length;s++){
                        System.out.print("Enter module "+(s+1)+" mark: ");
                        double moduleMark=scanner.nextDouble();
                        Module module=new Module(moduleMark);
                        moduleArr[s]=module;
                    }
                    System.out.println("Student marks added successfully.");
                    break;

                }
            }
        }
        if(!flag){
            System.out.println("No Such Student.");
        }

    }


    public static void summary(){
        boolean flag=false;
        int counter=0;
        System.out.println("Total Students Registered: "+studentCount);

        for(int i=0;i<studentsArr.length;i++){
            if(studentsArr[i]!=null){
                Student student=studentsArr[i];
                Module modArr[]=student.getModules();
                for(int p=0;p<modArr.length;p++){
                    if(modArr[i].getModuleMark()>40){
                        flag=true;// flag for handle the all the module marks greater than 40
                    }else{
                        flag=false;
                        break;
                    }
                }
                if(flag){
                    counter++;
                }
            }
        }
        System.out.println("Total students get more than 40 marks for all 3 modules: "+counter);
    }


    public static void report(){
        double total=0;
        double average=0;
        String grade="";
        int count=0;
        for(int i=0;i<studentsArr.length;i++){
            total=0;
            if(studentsArr[i]!=null){ //checking the array element is null or not
                Student student=studentsArr[i]; //Taking object to the variable
                Module moduleArr[]=student.getModules();
                System.out.println("Student ID: "+student.getStuId());
                System.out.println("Student Name: "+student.getStuName());
                for(Module module:moduleArr){
                    count++;
                    System.out.println("Module "+(count+1)+" Mark: "+module.getModuleMark());
                    total+=module.getModuleMark();
                }
                average=total/3;
                System.out.println("Total is : "+total);
                System.out.println("Average is : "+average);
                if(average>=80){
                    grade="Distinction";
                }else if(average>=70){
                    grade="Merit";
                }else if(average>=40){
                    grade="Pass";
                }else{
                    grade="Fail";
                }
                System.out.println("Grade: "+grade);
                System.out.println();
            }
        }
        System.out.println("************************************************************************");
    }

    public static void main(String args[]){
        int choice=0;
        while(true){
            displayMenu();
            boolean flag=false;
            Scanner scanner=new Scanner(System.in); //Take the Scanner class as the scanner
            while(true){
                try{
                    System.out.print("Enter your choice: ");
                    choice=scanner.nextInt();
                    break;
                }catch(Exception e){
                    System.out.println("Invalid number");
                }
            }
            switch(choice){
                case 1:checkAvailableSeats();break;
                case 2:registerStudent(scanner); break;
                case 3:deleteStudent(scanner); break;
                case 4:findStudent(scanner); break;
                case 5:storeDetailsToFile(); break;
                case 6:loadStudentDetailsFromFile(); break;
                case 7:viewTheStudentWithNames(); break;
                case 8:additionalOptions(scanner); break;
                case 9:flag=true; break;
                default:System.out.println("Invalid input.");
            }
            if(flag){
                System.out.println("Exiting...");
                break;
            }
        }
    }

    private static void displayMenu() {
        System.out.println("\nMenu :");
        System.out.println("1. Check available seats");
        System.out.println("2. Register student");
        System.out.println("3. Delete student");
        System.out.println("4. Find student");
        System.out.println("5. Store student details into a file"); // Serialization is not supported
        System.out.println("6. Load student details from the file to the system"); // Deserialization is not supported
        System.out.println("7. View the list of students based on their names");
        System.out.println("8. Additional Options");
        System.out.println("9. Exit");
    }


}