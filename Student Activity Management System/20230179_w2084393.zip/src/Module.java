public class Module {
    private double moduleMark;
    public Module(double moduleMark){
        this.moduleMark=moduleMark;
    }

    public double getModuleMark(){
        return moduleMark;
    }
}
